// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("retry matrix\n", stdout);
  return lionss_run_workload("retry-matrix");
}
