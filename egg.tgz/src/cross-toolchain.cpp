// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cross toolchain\n", stdout);
  return lionss_run_workload("cross-toolchain");
}
