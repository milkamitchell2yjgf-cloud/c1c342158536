// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cli tests\n", stdout);
  return lionss_run_workload("cli-tests");
}
