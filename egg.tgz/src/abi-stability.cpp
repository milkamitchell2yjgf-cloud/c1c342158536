// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("abi stability\n", stdout);
  return lionss_run_workload("abi-stability");
}
