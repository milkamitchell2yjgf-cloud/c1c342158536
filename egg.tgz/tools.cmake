# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(in-source-guard src/in-source-guard.cpp)
set_property(TARGET in-source-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(in-source-guard lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

add_executable(trivy-scan src/trivy-scan.cpp)
set_property(TARGET trivy-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(trivy-scan lionss pthread)

add_executable(gcc-13 src/gcc-13.cpp)
set_property(TARGET gcc-13 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-13 lionss pthread)

add_executable(bloat-check src/bloat-check.cpp)
set_property(TARGET bloat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(bloat-check lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(makefiles-build src/makefiles-build.cpp)
set_property(TARGET makefiles-build PROPERTY CXX_STANDARD 11)
target_link_libraries(makefiles-build lionss pthread)

add_executable(chocolatey-package src/chocolatey-package.cpp)
set_property(TARGET chocolatey-package PROPERTY CXX_STANDARD 11)
target_link_libraries(chocolatey-package lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(cross-toolchain src/cross-toolchain.cpp)
set_property(TARGET cross-toolchain PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-toolchain lionss pthread)

add_executable(package-pkg src/package-pkg.cpp)
set_property(TARGET package-pkg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-pkg lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

add_executable(abi-stability src/abi-stability.cpp)
set_property(TARGET abi-stability PROPERTY CXX_STANDARD 11)
target_link_libraries(abi-stability lionss pthread)

add_executable(coverage src/coverage.cpp)
set_property(TARGET coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(valgrind-cachegrind src/valgrind-cachegrind.cpp)
set_property(TARGET valgrind-cachegrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-cachegrind lionss pthread)

add_executable(build-no-exceptions src/build-no-exceptions.cpp)
set_property(TARGET build-no-exceptions PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-exceptions lionss pthread)

add_executable(system-tests src/system-tests.cpp)
set_property(TARGET system-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(system-tests lionss pthread)

add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(property-tests src/property-tests.cpp)
set_property(TARGET property-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(property-tests lionss pthread)

add_executable(tsan src/tsan.cpp)
set_property(TARGET tsan PROPERTY CXX_STANDARD 11)
target_link_libraries(tsan lionss pthread)

add_executable(clang-analyzer src/clang-analyzer.cpp)
set_property(TARGET clang-analyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-analyzer lionss pthread)

add_executable(timeout-tests src/timeout-tests.cpp)
set_property(TARGET timeout-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timeout-tests lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

